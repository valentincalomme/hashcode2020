from __future__ import annotations


class Solver:
    def yield_solutions(self, problem: Problem) -> Solution:

        raise NotImplementedError
