# Hashcode 2020

Hashcode Qualification Round 2020

## Installation

To install the requirements, the recommended use is to use Poetry:

`pip install poetry`

Then simply run the following command to install all dependencies

`poetry install`

To activate the environment, run:

`poetry shell`

Or simply prepend every command with:

`poetry run`